# MCAG Starterpaket

Dieses Starterpaket liefert die Grundstruktur für einen **Meta‑Controlling‑Agent‑GPT (MCAG)**.
Es enthält exemplarische Policies, SLOs, Gates, Prompts, Experimente, Tests, Runbooks und Konfigurationen,
um zügig von **MVP → Alpha → Beta → Prod** zu gelangen.

> Hinweis: Alle Dateien sind **Platzhalter**. Ergänze projektspezifische Inhalte (KPIs, Policies, Rollen, Connectoren).
