# Scripts (Platzhalter)

- `evaluate.py` – führt Tests aus und schreibt Ergebnisse nach `./reports`
- `promote.py` – prüft Gates und setzt Release-Status (alpha|beta|prod)
